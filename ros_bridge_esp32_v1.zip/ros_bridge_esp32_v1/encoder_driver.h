#define LEFT_ENC_PIN_A   23
#define LEFT_ENC_PIN_B   19
#define RIGHT_ENC_PIN_A  16
#define RIGHT_ENC_PIN_B  17

void initEncoders();
long readEncoder(int i);
void resetEncoder(int i);
void resetEncoders();

