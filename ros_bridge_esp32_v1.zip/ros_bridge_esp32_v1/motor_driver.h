#define LEFT_MOTOR_FORWARD   18 // IN1
#define LEFT_MOTOR_BACKWARD  5 // IN2
#define LEFT_MOTOR_ENABLE    25 // ENA
#define RIGHT_MOTOR_FORWARD  4 // IN3
#define RIGHT_MOTOR_BACKWARD 15 // IN4
#define RIGHT_MOTOR_ENABLE   26 // ENB

void initMotorController();
void setMotorSpeed(int i, int spd);
void setMotorSpeeds(int leftSpeed, int rightSpeed);


