#ifndef COMMANDS_H //Header Guard
#define COMMANDS_H //Header Guard

#define GET_BAUDRATE   'b'
#define READ_ENCODERS  'e'
#define MOTOR_RAW_PWM  'o'
#define RESET_ENCODERS 'r'
#define SERVO_MOTOR 's'
#define DIGITAL_OUTPUT  'l'
#define LEFT   0
#define RIGHT  1

#endif  // COMMANDS_H
